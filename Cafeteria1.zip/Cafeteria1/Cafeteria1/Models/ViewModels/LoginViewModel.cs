﻿using System.ComponentModel.DataAnnotations;

namespace cafeteria.Models.ViewModels
{
    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Documento")]
        public required int Doc { get; set; }

        [Required]
        [Display(Name = "Contraseña")]
        [StringLength(10)]
        public required string Clave { get; set; }
    }
}
