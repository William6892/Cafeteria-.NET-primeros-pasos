﻿using System.ComponentModel.DataAnnotations;

namespace Cafeteria.Models.ViewModels
{
    public class UsuarioEditViewModel
    {
        [Required]
        [Display(Name = "Documento")]
        public required int Doc { get; set; }

        [Required]
        [Display(Name = "Nombre del Cliente")]
        [StringLength(30)]
        public required string Nombre { get; set; }

        [Required]
        [Display(Name = "Correo Electrónico")]
        [StringLength(30)]
        [EmailAddress]
        public required string Correo { get; set; }

        [Display(Name = "Tipo")]
        public string? Tipo { get; set; }
        public int? Id { get; set; }
    }
}
