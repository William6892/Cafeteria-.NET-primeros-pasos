﻿using System.ComponentModel.DataAnnotations;

namespace Cafeteria.Models
{
    public class Proveedor
    {
        public int Id_prov { get; set; }

        [Required]
        [Display(Name = "NIT")]
        [StringLength(13)]
        public string Nit_prov { get; set; }

        [Required]
        [Display(Name = "Nombre")]
        [StringLength(30)]
        public string Nom_prov { get; set; }

        [Required]
        [Display(Name = "Correo Eletrónico")]
        [StringLength(30)]
        [EmailAddress]
        public string Mail_prov { get; set; }
    }
}
