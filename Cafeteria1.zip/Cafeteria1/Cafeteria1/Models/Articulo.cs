﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace Cafeteria.Models
{
    public class Articulo
    {
        public int Id_art { get; set; }

        [Required]
        [Display(Name = "Código")]
        [StringLength(10)]
        public string Cod_art { get; set; }

        [Required]
        [Display(Name = "Nombre Artículo")]
        [StringLength(30)]
        public string Nom_art { get; set; }

        [Required]
        [Display(Name = "Existencias")]
        public int Exist_art { get; set; }

        [Required]
        [Display(Name = "Precio")]
        public float Precio_art { get; set; }

        [Display(Name = "Imagen")]
        public string? Foto_art { get; set; }

        [Required]
        [Display(Name = "Proveedor")]
        public int Id_prov { get; set; }

        public Proveedor? Prov { get; set; }

        public IEnumerable<SelectListItem>? ListaProvs { get; set; }
    }
}
