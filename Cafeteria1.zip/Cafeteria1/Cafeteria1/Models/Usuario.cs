﻿namespace Cafeteria.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public int Doc { get; set; }
        public string? Nombre { get; set; }
        public string? Correo { get; set; }
        public string? Clave { get; set; }
        public string? Tipo { get; set; }
    }
}
