﻿using cafeteria.Models.ViewModels;
using Cafeteria.Models;
using Cafeteria.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;

namespace cafeteria.Controllers
{
    public class UsuarioController : Controller
    {
        // GET: UsuarioController
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (HttpContext.Session.GetString("msjOk") != null)
            {
                ViewData["msj"] = HttpContext.Session.GetString("msjOk");
                HttpContext.Session.Remove("msjOk");
            }

            return View(ListarUsers());
        }

        public List<Usuario> ListarUsers()
        {
            List<Usuario> usuarios = new List<Usuario>();

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT *  FROM usuario";

            MySqlCommand cmd = new MySqlCommand(sql, con);

            MySqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Usuario user = new Usuario
                {
                    Id = dr.GetInt32("id"),
                    Doc = dr.GetInt32("doc"),
                    Nombre = dr.GetString("nombre"),
                    Correo = dr.GetString("correo"),
                    Clave = dr.GetString("clave"),
                    Tipo = dr.GetString("tipo")
                };

                usuarios.Add(user);
            }

            con.Close();

            return usuarios;
        }

        // GET: UsuarioController/Create
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            return View();
        }

        // POST: UsuarioController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(RegistroViewModel user)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();  
                con.Open();

                string clave = Utilidades.EncriptarClave(user.Clave);

                string sql = "INSERT INTO usuario (doc, nombre, correo, clave, tipo) " +
                    " VALUES('" + user.Doc + "', '" + user.Nombre + "', '" + user.Correo + "', '" + clave + "', '" + user.Tipo + "')";

                MySqlCommand cmd = new MySqlCommand(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error creando Usuario";
                }

                con.Close();

                HttpContext.Session.SetString("msjOk", "Usuario guardado exitosamente");
                return Redirect("Index");
            }

            return View();
        }

        // GET: UsuarioController/Edit/5
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT * FROM usuario WHERE id = " + id;

            MySqlCommand cmd = new MySqlCommand(sql, con);

            MySqlDataReader dr = cmd.ExecuteReader();

            UsuarioEditViewModel user = null;

            if (dr.Read())
            {
                user = new UsuarioEditViewModel
                {
                    Id = dr.GetInt32("id"),
                    Doc = dr.GetInt32("doc"),
                    Nombre = dr.GetString("nombre"),
                    Correo = dr.GetString("correo"),
                    Tipo = dr.GetString("Tipo")
                };
            }

            con.Close();

            return View(user);
        }

        // POST: UsuarioController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(UsuarioEditViewModel user)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string sql = "UPDATE usuario SET doc = '" + user.Doc + "', nombre = '" + user.Nombre + "'," +
                    " correo = '" + user.Correo + "', tipo = '" + user.Tipo + "'  WHERE id = " + user.Id;

                MySqlCommand cmd = new MySqlCommand(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error actualizando Usuario";
                    return View(user);
                }

                con.Close();

                HttpContext.Session.SetString("msjOk", "Usuario actualizado exitosamente");
                return RedirectToAction("Index");
            }

            return View();
        }

        // GET: UsuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "DELETE FROM usuario WHERE id = " + id;

            MySqlCommand cmd = new MySqlCommand(sql, con);

            cmd.ExecuteNonQuery();

            con.Close();

            HttpContext.Session.SetString("msjOk", "Usuario eliminado exitosamente");
            return RedirectToAction("Index");
        }
    }
}
