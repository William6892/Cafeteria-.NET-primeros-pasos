﻿using cafeteria.Controllers;
using Cafeteria.Controllers;
using Cafeteria.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MySqlConnector;
using System.Data;

namespace Picolo.Controllers
{
    public class ArticuloController : Controller
    {
        // GET: ArticuloController
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (HttpContext.Session.GetString("msjOk") != null)
            {
                ViewData["msj"] = HttpContext.Session.GetString("msjOk");
                HttpContext.Session.Remove("msjOk");
            }

            return View(ListarArts());
        }

        public static Articulo BuscarArt(int id)
        {
            Articulo art = new Articulo();

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT * FROM articulo WHERE id_art = " + id;

            MySqlCommand cmd = new(sql, con);

            MySqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                art = new Articulo
                {
                    Id_art = dr.GetInt32("id_art"),
                    Cod_art = dr.GetString("cod_art"),
                    Nom_art = dr.GetString("nom_art"),
                    Exist_art = dr.GetInt32("exist_art"),
                    Precio_art = dr.GetFloat("precio_art"),
                    Foto_art = dr.GetString("foto_art"),
                    Id_prov = dr.GetInt32("id_prov"),
                    Prov = ProveedorController.buscarProv(dr.GetInt32("id_prov"))
                };
            }

            con.Close();

            return art;
        }

        public List<Articulo> ListarArts()
        {
            List<Articulo> articulos = new List<Articulo>();

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT * FROM articulo";

            MySqlCommand cmd = new MySqlCommand(sql, con);

            MySqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Articulo art = new Articulo
                {
                    Id_art = dr.GetInt32("id_art"),
                    Cod_art = dr.GetString("cod_art"),
                    Nom_art = dr.GetString("nom_art"),
                    Exist_art = dr.GetInt32("exist_art"),
                    Precio_art = dr.GetFloat("precio_art"),
                    Foto_art = dr.GetString("foto_art"),
                    Id_prov = dr.GetInt32("id_prov"),
                    Prov = ProveedorController.buscarProv(dr.GetInt32("id_prov"))
                };

                articulos.Add(art);
            }

            con.Close();

            return articulos;
        }


        // GET: ArticuloController/Create
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (HttpContext.Session.GetString("msjOk") != null)
            {
                ViewData["msj"] = HttpContext.Session.GetString("msjOk");
                HttpContext.Session.Remove("msjOk");
            }

            Articulo art = new Articulo();
            art.ListaProvs = new SelectList(ProveedorController.ListProvs(), "Id_prov", "Nom_prov", art.Id_prov);

            return View(art);
        }

        // POST: ArticuloController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Articulo art, IFormFile imagen)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                string dir_pag = Environment.CurrentDirectory;
                string ext = Path.GetExtension(imagen.FileName);
                string nom = art.Cod_art + ext;
                string path = Path.Combine(dir_pag + "\\wwwroot\\FotosArt", nom);

                art.Foto_art = nom;

                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string sql = "INSERT INTO articulo (cod_art, nom_art, exist_art, precio_art, foto_art, id_prov) " +
                    " VALUES('" + art.Cod_art + "', '" + art.Nom_art + "', '" + art.Exist_art + "', " +
                    "'" + art.Precio_art + "', '" + art.Foto_art + "', '" + art.Id_prov + "')";

                MySqlCommand cmd = new MySqlCommand(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();

                    using (FileStream nuevo = System.IO.File.Create(path))
                    {
                        imagen.CopyTo(nuevo);
                        nuevo.Flush();
                    }

                    HttpContext.Session.SetString("msjOk", "Artículo creado exitosamente");
                    return Redirect("Index");
                }
                catch (Exception)
                {
                    ViewData["msj"] = "Error creando Artículo";
                }

                con.Close();
            }

            art.ListaProvs = new SelectList(ProveedorController.ListProvs(), "Id_prov", "Nom_prov", art.Id_prov);
            return View(art);
        }

        // GET: ArticuloController/Edit/5
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            Articulo art = BuscarArt(id);
            art.ListaProvs = new SelectList(ProveedorController.ListProvs(), "Id_prov", "Nom_prov", art.Id_prov);

            return View(art);
        }

        // POST: ArticuloController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Articulo art, IFormFile? imagen)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                if (imagen != null)
                {
                    string dir_pag = Environment.CurrentDirectory;
                    string ext = Path.GetExtension(imagen.FileName);
                    string nom = art.Cod_art + ext;
                    string path = Path.Combine(dir_pag + "\\wwwroot\\FotosArt", nom);

                    using (FileStream nuevo = System.IO.File.Create(path))
                    {
                        imagen.CopyTo(nuevo);
                        nuevo.Flush();
                    }

                    art.Foto_art = nom;
                }

                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string sql = "UPDATE articulo SET cod_art = '" + art.Cod_art + "', nom_art = '" + art.Nom_art + "'," +
                    " exist_art = '" + art.Exist_art + "', precio_art = '" + art.Precio_art + "', foto_art = '" + art.Foto_art + "'," +
                    " id_prov = '" + art.Id_prov + "' WHERE id_art = " + art.Id_art;

                MySqlCommand cmd = new MySqlCommand(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();

                    HttpContext.Session.SetString("msjOk", "Artículo actualizado exitosamente");
                    return RedirectToAction("Index");
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error actualizando Artículo";
                }

                con.Close();
            }

            art.ListaProvs = new SelectList(ProveedorController.ListProvs(), "Id_prov", "Nom_prov", art.Id_prov);
            return View(art);
        }

        // GET: ArticuloController/Delete/5
        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "DELETE FROM articulo WHERE id_art = " + id;

            MySqlCommand cmd = new MySqlCommand(sql, con);

            try
            {
                cmd.ExecuteNonQuery();

                HttpContext.Session.SetString("msjOk", "Artículo eliminado exitosamente");
                return RedirectToAction("Index");
            }
            catch (MySqlException)
            {
                ViewData["msj"] = "Error eliminando Artículo";
            }

            return View("Index");
        }

    }
}
