﻿using MySqlConnector;
using System.Security.Cryptography;
using System.Text;

namespace cafeteria.Controllers
{
    public class Utilidades
    {
        public static MySqlConnection ConectarBD()
        {
            string cad = "server=localhost; database=cafeteria; uid=root";

            return new MySqlConnection(cad);
        }

        public static string EncriptarClave(string cad)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] stream;
            StringBuilder sb = new StringBuilder();

            stream = SHA256.HashData(encoding.GetBytes(cad));

            for (int i = 0; i< stream.Length; i++ )
            {
                sb.AppendFormat("{0:x2}", stream[i]);
            }

            return sb.ToString();
        }

    }
}
