﻿using Microsoft.AspNetCore.Mvc;

namespace Cafeteria.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
            {
                ViewData["User"] = HttpContext.Session.GetString("User");
            }

            if (ViewData["User"] == null)
            {
                return View("Index");
            }
            return View();
        }
    }
}
