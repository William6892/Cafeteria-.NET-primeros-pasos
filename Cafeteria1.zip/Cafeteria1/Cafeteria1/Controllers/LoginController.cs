﻿using cafeteria.Controllers;
using cafeteria.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;

namespace Cafeteria.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel user)
        {
            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string clave = Utilidades.EncriptarClave(user.Clave);

                string sql = "SELECT * FROM usuario WHERE doc = '" + user.Doc + "' AND clave =  '" + clave + "'";

                MySqlCommand cmd = new MySqlCommand(sql, con);

                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    HttpContext.Session.SetString("User", dr.GetString("nombre"));
                    HttpContext.Session.SetString("Tipo", dr.GetString("tipo"));

                    if (dr.GetString("tipo") == "A")
                    {
                        return Redirect("~/Admin/Index");
                    }
                    else
                    {
                        return Redirect("~/Cliente/Index");
                    }
                }
                else
                {
                    ViewData["msj"] = "Documento y/o Contraseña no son válidos";
                }

                con.Close();
            }

            return View("Index");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Tipo");
            HttpContext.Session.Remove("User");
            return Redirect("Index");
        }

        public IActionResult Registro()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Registro(RegistroViewModel user)
        {
            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string clave = Utilidades.EncriptarClave(user.Clave);

                string sql = "INSERT INTO usuario (doc, nombre, correo, clave) " +
                    " VALUES('" + user.Doc + "', '" + user.Nombre + "', '" + user.Correo + "', '" + clave + "')";

                MySqlCommand cmd = new MySqlCommand(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error creando Cliente";
                    return View();
                }

                con.Close();

                HttpContext.Session.SetString("User", user.Nombre);
                HttpContext.Session.SetString("Tipo", "C");

                return Redirect("~/Cliente/Index");
            }

            return View();
        }
    }
}