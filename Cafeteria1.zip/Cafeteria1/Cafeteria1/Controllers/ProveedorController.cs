﻿using cafeteria.Controllers;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using Cafeteria.Models;

namespace Cafeteria.Controllers
{
    public class ProveedorController : Controller
    {
        // GET: ProveedorController
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (HttpContext.Session.GetString("msjOk") != null)
            {
                ViewData["msj"] = HttpContext.Session.GetString("msjOk");
                HttpContext.Session.Remove("msjOk");
            }

            return View(ListProvs());
        }

        public static Proveedor buscarProv(int id)
        {
            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT * FROM proveedor WHERE id_prov = " + id;

            MySqlDataReader dr = new MySqlCommand(sql, con).ExecuteReader();

            Proveedor prov = new Proveedor();

            if (dr.Read())
            {
                prov = new Proveedor
                {
                    Id_prov = dr.GetInt32("id_prov"),
                    Nit_prov = dr.GetString("nit_prov"),
                    Nom_prov = dr.GetString("nom_prov"),
                    Mail_prov = dr.GetString("mail_prov")
                };
            }

            con.Close();
            return prov;
        }

        public static List<Proveedor> ListProvs()
        {
            List<Proveedor> lstProvs = new();

            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "SELECT * FROM proveedor";

            MySqlDataReader dr = new MySqlCommand(sql, con).ExecuteReader();

            while (dr.Read())
            {
                Proveedor prov = new Proveedor
                {
                    Id_prov = dr.GetInt32("id_prov"),
                    Nit_prov = dr.GetString("nit_prov"),
                    Nom_prov = dr.GetString("nom_prov"),
                    Mail_prov = dr.GetString("mail_prov")
                };

                lstProvs.Add(prov);
            }

            con.Close();

            return lstProvs;
        }

        // GET: ProveedorController/Create
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            return View();
        }

        // POST: ProveedorController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Proveedor prov)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string sql = "INSERT INTO proveedor (nit_prov, nom_prov, mail_prov)" +
                    " VALUES('" + prov.Nit_prov + "', '" + prov.Nom_prov + "', '" + prov.Mail_prov + "')";

                MySqlCommand cmd = new(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error creando Proveedor.";
                    return View();
                }

                con.Close();

                HttpContext.Session.SetString("msjOk", "Proveedor creado exitosamente");
                return Redirect("Index");
            }

            return View();
        }

        // GET: ProveedorController/Edit/5
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            return View(buscarProv(id));
        }

        // POST: ProveedorController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Proveedor prov)
        {
            if (HttpContext.Session.GetString("Tipo") == "A")
                ViewData["User"] = HttpContext.Session.GetString("User");

            if (ViewData["User"] == null)
            {
                return View("Index");
            }

            if (ModelState.IsValid)
            {
                MySqlConnection con = Utilidades.ConectarBD();
                con.Open();

                string sql = "UPDATE proveedor SET nit_prov = '" + prov.Nit_prov + "', nom_prov = '" + prov.Nom_prov + "'," +
                    " mail_prov = '" + prov.Mail_prov + "' WHERE id_prov = " + prov.Id_prov;

                MySqlCommand cmd = new(sql, con);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException)
                {
                    ViewData["msj"] = "Error actualizando Proveedor.";
                    return View();
                }

                con.Close();

                HttpContext.Session.SetString("msjOk", "Proveedor actualizado exitosamente");
                return RedirectToAction("Index");
            }

            return View();
        }

        // GET: ProveedorController/Delete/5
        public ActionResult Delete(int id)
        {
            MySqlConnection con = Utilidades.ConectarBD();
            con.Open();

            string sql = "DELETE FROM proveedor WHERE id_prov = " + id;

            MySqlCommand cmd = new(sql, con);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException)
            {
                ViewData["msj"] = "Error eliminando Provedor";
                return View();
            }

            con.Close();

            HttpContext.Session.SetString("msjOk", "Proveedor eliminado exitosamente");
            return RedirectToAction("Index");
        }
    }
}
